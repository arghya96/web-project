/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.project.dao;
import com.project.bean.user;
import com.project.connection.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class UserDao {
     public static int registerDao(user ub) throws ClassNotFoundException {
        int status = 0;
        try {
            try (Connection con = DbConnection.connect()) {
                PreparedStatement ps = con.prepareStatement("insert into registration values(?,?,?,?,?)");
                ps.setString(1, ub.getUsername());
                ps.setString(2, ub.getPassword());
                ps.setString(3, ub.getEmail());
                ps.setString(4, ub.getPhone());
                ps.setString(5, ub.getGender());
                
                 status= ps.executeUpdate();
              
            }

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
         
         return status;
         
       
     }

 public boolean isValidUser(String un, String pwd) throws ClassNotFoundException {

        boolean flag = false;

        String sql = "select * from registration  where username=? and Password=?";
        try {
            Connection con = DbConnection.connect();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, un);
            ps.setString(2, pwd);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                flag = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;

    }


 public user getUserData(String un, String pwd) throws ClassNotFoundException, SQLException {

        user ub = new user();
        Connection con = DbConnection.connect();
        String sql = "select * from registration where username=? and password=?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, un);
            ps.setString(2, pwd);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ub.setUsername(rs.getString(1));
                ub.setPassword(rs.getString(3));
                ub.setEmail(rs.getString(2));
                ub.setPhone(rs.getString(4));
                ub.setGender(rs.getString(5));
               
               
                

            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ub;
    }
}