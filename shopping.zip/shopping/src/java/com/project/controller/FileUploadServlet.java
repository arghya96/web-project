
package com.project.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@MultipartConfig(fileSizeThreshold=1024*1024*2,
maxFileSize=1024*1024*10,
maxRequestSize=1024*1024*50)
public class FileUploadServlet extends HttpServlet {

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String id=request.getParameter("id");
            String name=request.getParameter("fileName");
            Part part=request.getPart("file");
            String fileName=extractFileName(part);
            String savePath="C:\\Users\\Sudipto Hazra\\Documents\\NetBeansProjects\\shopping\\web\\image2"+File.separator+fileName;
           File fileSaveDir=new File(savePath);
           part.write(savePath+File.separator);
           try{
               Class.forName("com.mysql.jdbc.Driver");
               Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flower","root","");
               PreparedStatement pst=con.prepareStatement("insert into product images values(?,?,?)");
           pst.setString(1, id);
           pst.setString(2, fileName);
           pst.setString(3,savePath );
           pst.executeUpdate();
           out.println("image inserted successfully");
           out.println("<center><a href='Display.jsp?id="+id+"'>Display</a></center");
           }
           catch(Exception e){
               out.println(e);
           }
           
        }
    }
    private String extractFileName(Part part) {
    String contentDisp=part.getHeader("content-disposition");
    String[] items=contentDisp.split(";");
    for(String s: items){
        if(s.trim().startsWith("fileName")){
            return s.substring(s.indexOf("=")+2, s.length()-1);
        }
    }
    return "";
    }
}

