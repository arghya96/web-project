/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.project.controller;

import java.io.*;
import java.lang.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.DriverManager;

public class feedback extends HttpServlet{
  @Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
        try{
      String username = request.getParameter("username");
      String describe = request.getParameter("describe");
      String email = request.getParameter("email");
      String productname=request.getParameter("productname");
            System.out.println("value inserting");
      out.println(username);
      out.println(email);
      out.println(describe);
            System.out.println("value inserted");
      Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
      PreparedStatement pst = con.prepareStatement("insert into review values(?,?,?,?)");
      pst.setString(1,describe);
      pst.setString(2,username);
      pst.setString(3, email);
       pst.setString(4, productname);
      int i = pst.executeUpdate();
      if(i!=0){
        request.getRequestDispatcher("/afterlogin.jsp").include(request, response);
      }
      else{
        out.println("failed to insert the data");
      }
    }
    catch (Exception e){
      out.println(e);
    }
  }
}