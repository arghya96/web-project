/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.project.controller;

import com.project.bean.user;
import com.project.dao.UserDao;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
//import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.annotation.WebServlet;
/**
 *HttpServletResponse
 * @author Sudipto Hazra
  */
@WebServlet(name="LoginCon",urlPatterns={"/LoginCon"})
public class LoginCon extends HttpServlet {
     
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
        String un = request.getParameter("username");
       String pwd = request.getParameter("password"); 
       UserDao t=new UserDao();
        try {
            if(t.isValidUser(un, pwd))
            {
        
                user u=t.getUserData(un, pwd);
                HttpSession session = request.getSession();
                
                session.setAttribute("Username", u.getUsername());
                session.setAttribute("u", u);
                request.setAttribute("message", "<font color='green' size='5'> Welcome : "+u.getUsername()+"</font>");
               // request.getRequestDispatcher("/index.jsp").include(request, response);
                ServletContext ctx = getServletContext();
                RequestDispatcher rd = ctx.getRequestDispatcher("/afterlogin.jsp");
                rd.forward(request, response);
                System.out.println(" #####################");
            }else{
                System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$444");
                request.setAttribute("message", "<font color='red' size='5'>Invalid username or password</font>"); 
               // request.getRequestDispatcher("/register.jsp").include(request, response);
                ServletContext ctx = getServletContext();
                RequestDispatcher rd = ctx.getRequestDispatcher("/reglogin.jsp");
                rd.forward(request, response);
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(LoginCon.class.getName()).log(Level.SEVERE, null, ex);
        }
        
      
      
      
        }
}
