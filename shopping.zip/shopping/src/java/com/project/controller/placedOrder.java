/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.project.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Win10
 */
public class placedOrder extends HttpServlet {

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       response.setContentType("text/html");
    PrintWriter out = response.getWriter();
        try{
      String address = request.getParameter("address");
      String pname = request.getParameter("ab");
      String price = request.getParameter("bc");
      
            System.out.println("value inserting");
      System.out.println(address);
      System.out.println(pname);
      System.out.println(price);
            System.out.println("value inserted");
      Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
      PreparedStatement pst = con.prepareStatement("insert into order values('"+address+"','"+pname+"','"+price+"')");
      pst.setString(1,address);
      pst.setString(2,pname);
      pst.setString(3, price);
      
      int i = pst.executeUpdate();
      if(i!=0){
        out.println("<br>Record has been inserted");
      }
      else{
        out.println("failed to insert the data");
      }
    }
    catch (Exception e){
      out.println(e);
    }
        request.getRequestDispatcher("/afterlogin.jsp").include(request, response);
    }

}