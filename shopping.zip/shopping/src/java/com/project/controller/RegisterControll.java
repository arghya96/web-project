/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.project.controller;

import com.project.bean.user;
import com.project.dao.UserDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Sudipto Hazra
 */


public class RegisterControll extends HttpServlet
{
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            user ub = new  user();
            ub.setUsername(request.getParameter("Username"));
            ub.setPassword(request.getParameter("Password"));
            ub.setEmail(request.getParameter("email"));
            ub.setPhone(request.getParameter("mobile"));
            ub.setGender(request.getParameter("gender"));
            
           
              try {
            int status=UserDao.registerDao(ub);
            
            } catch (ClassNotFoundException ex) {
            Logger.getLogger(RegisterControll.class.getName()).log(Level.SEVERE, null, ex);
            
            }
            int status=0;
            
            if(status == 0){
                request.setAttribute("message", "<font color='yellow' size='5'>Congratulations!! Registration successful.</font>");
                out.println("success");
            }
            
            
            if(status==1){
                request.setAttribute("message", "<font color='Red' size='5'>Oops!! something went wrong, please try again.</font>");
                out.println("failed");
            }
            
            
            
            /*  if(status>0)
            {
            out.println("<h1>Resistration sucessfull</h1>");
            //out.println("<h1>Do u insert more record</h1><a href=index.jsp>CLICK</a>");
            out.println("<h2>go to the login page</h2><a href=index.jsp>Login</a>");
            }
            else
            {
            out.println("registration unsucessfull");
            
            }*/
            request.getRequestDispatcher("/reglogin.jsp").include(request, response);
        } //End of doPost()
        
    }
 
    
    
