/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.project.controller;

import com.project.bean.user;
import com.project.dao.UserDao;
import java.io.*;
import java.lang.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.DriverManager;
import javax.servlet.http.HttpSession;

public class addressController extends HttpServlet{
  @Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    HttpSession session = request.getSession();
    user u = (user)session.getAttribute("u");
        try{
      String phone = request.getParameter("phone");
      String email = request.getParameter("email");
      String addr = request.getParameter("address");
      String city=request.getParameter("city");
      String state = request.getParameter("state");
      String zip=request.getParameter("zip");
      String username=request.getParameter("username");
            System.out.println(phone);
     
            System.out.println(email);
            System.out.println(addr);
            System.out.println(city);
     
            System.out.println(state);
            System.out.println(zip);
            System.out.println(username);
           
      Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
      PreparedStatement pst = con.prepareStatement("insert into address values(?,?,?,?,?,?,?)");
      pst.setString(1,phone);
      pst.setString(2,email);
      pst.setString(3, addr);
       pst.setString(4, city);
       pst.setString(5,state);
      pst.setString(6,zip);
      pst.setString(7, username);
       
      int i = pst.executeUpdate();
      if(i!=0){
        request.getRequestDispatcher("/orderSuccessful.jsp").include(request, response);
      }
      else{
        out.println("failed to insert the data");
      }
    }
    catch (Exception e){
      out.println(e);
    }
  }
}